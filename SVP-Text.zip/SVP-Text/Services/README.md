Mockup Slideshow
=========

An animated perspective mockup slideshow with 3D transforms computed with [Franklin Ta's helper script](http://franklinta.com/2014/09/08/computing-css-matrix3d-transforms/)

[Article on Codrops](http://tympanus.net/codrops/?p=21345)

[Demo](http://tympanus.net/Development/MockupSlideshow/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

Free Mockup images from: 
Demo 1 and 3: https://www.behance.net/gallery/19352531/Free-PSD-mockup-vol-2
Demo 4: http://pixelbuddha.net/freebie/morning-device-mockups

Demo 2 image copygrighted by Vadim Sherbakov with granted permission to be used in this demo: 
https://creativemarket.com/Vadim.Sherbakov/50038-6-Macbook-In-the-house-mock-ups
http://madebyvadim.robot.co/
https://creativemarket.com/Vadim.Sherbakov

[Line Icons](http://pixelbuddha.net/freebie/280-line-icons-pack) by Jonas Nullens for PixelBuddha

Follow us: [Twitter](http://www.twitter.com/codrops), [Facebook](http://www.facebook.com/pages/Codrops/159107397912), [Google+](https://plus.google.com/101095823814290637419), [GitHub](https://github.com/codrops), [Pinterest](http://www.pinterest.com/codrops/)

[© Codrops 2014](http://www.codrops.com)