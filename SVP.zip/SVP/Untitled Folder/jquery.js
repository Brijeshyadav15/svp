 function validate()
            {     
              $(document).ready(function(){
                $("#submit").validate({
              	  rules: {
                      uname: "required",
                        user: "required",
                        dob: "required",
                      email: 
                              {
                      required: true,
                      email: true
                      },
                      psd: 
                              {
                      required: true,
                      minlength: 5
                      },
                   },

             	   messages: {
                      uname: "Please enter your Name",
                      user: "Please enter your Username",
                      psd: 
                              {
                      required: "Please provide a password",
                      minlength: "Your password must be at least 5 characters long"
                      },
                        email: "Please enter a valid email address"
                    },
                   
            });
        });  
        }            
           