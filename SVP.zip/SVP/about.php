<!DOCTYPE html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>About - SVP</title>
	<link rel="icon" type="image/x-icon" href="assets/images//favicon.ico" />
	<link rel="apple-touch-icon-precomposed" href="assets/images//apple-touch-icon-114x114-precomposed.png">
	<link rel="apple-touch-icon-precomposed" href="assets/images//apple-touch-icon-72x72-precomposed.png">
	<link rel="apple-touch-icon-precomposed" href="assets/images//apple-touch-icon-57x57-precomposed.png">
	<link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i|Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="assets/css/lib.css" rel="stylesheet">
	<link href="assets/css/plugins.css" rel="stylesheet">
	<link href="assets/css/elements.css" rel="stylesheet">	
	<link href="assets/css/rtl.css" rel="stylesheet">	
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body data-offset="200" data-spy="scroll" data-target=".ownavigation">
	<div class="main-container">
		<div id="site-loader" class="load-complete">
			<div class="loader">
				<div class="loader-inner ball-clip-rotate">
					<div></div>
				</div>
			</div>
		</div>
			<header class="header_s header_s2">
			<div id="slidepanel">
				<div class="container-fluid no-left-padding no-right-padding top-header">
					<div class="container">
						<div class="row">
							<div class="col-md-6 col-sm-6 col-xs-12 welcome-line">
								<h6>Welcome to Stock Value Predictor</h6>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-12 block-cnt">
								<ul class="top-social">
									<li><a href="#" title="Twitter"><i class="fa fa-pinterest-p"></i></a></li>
									<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
									<li><a href="#" title="linkedin"><i class="fa fa-linkedin"></i></a></li>
								</ul>
								<a href="#">Search</a>
							</div>
						</div>
					</div><!-- Container /- -->
				</div><!-- Top Header /- -->
				<!-- Middle Header -->
				<div class="container-fluid no-left-padding no-right-padding middle-header">
					<!-- Container -->
					<div class="container">
						<div class="row">
							<div class="col-md-offset-2 col-md-10">
								<span><i class="icon icon-Phone2"></i><a>(+01) 123 456 7890</a></span>
								<span><i class="icon icon-Mail"></i><a href="mailto:info@svp.in">info@svp.in</a></span>
								<div class="search-block">
									<div class="input-group">
										<input type="text" class="form-control" placeholder="Search for...">
										<span class="input-group-btn">
											<button class="btn btn-default" type="button"><i class="icon icon-Search"></i></button>
										</span>
									</div><!-- /input-group -->
								</div>
							</div>
						</div>
					</div><!-- Container /- -->
				</div><!-- Middle Header /- -->
			</div><!-- SidePanel /- -->
			
			<!-- Ownavigation -->
			<nav class="navbar ownavigation">
				<!-- Container -->
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="index.php"><img src="" alt="logo"></a>
					</div>
					<div class="menu-switch">	
						<a href="javascript:void(0);" title="menu"><i class="fa fa-bars"></i></a>
					</div>
					<div id="navbar" class="navbar-collapse collapse navbar-right">
						<ul class="nav navbar-nav">
							<li class="dropdown active">
								<a href="index.php" class="dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false">Home</a>
								<i class="ddl-switch fa fa-angle-down"></i>
							</li>
							<li><a href="about.php" title="About Us">About Us</a></li>
							<li><a href="about.php" title="About Us">Info</a></li>
							<li><a href="about.php" title="About Us">ANALYSIS</a></li>
							<li><a href="about.php" title="About Us">HISTORISIS</a></li>

							<li><a href="#" title="Services">Services</a></li>
							<li><a href="contactus.html" title="Contact">Contact</a></li>
						</ul>
					</div>
				</div><!-- Container /- -->
			</nav><!-- Ownavigation /- -->
		</header>
			
		<!-- Page Header -->
		<div class="container-header no-left-padding no-right-padding page-banner text-center">
			<!-- Container -->
			<div class="container">
				<h3>ABOUT US</h3>
				<p>Making Trading easier, by predicting the unpredictable!</p>
			</div><!-- Container /- -->
		</div><!-- Page Header /- -->
		<div class="clearfix"></div>
		<main>
			<div class="container-fluid no-left-padding no-right-padding about-section abtp-mp-change">
				<div class="container">
					<div class="row">
						<div class="col-md-7 col-sm-6 col-xs-12">
							<div class="section-header text-left">
								<h6>About Our Max</h6>
								<h3>How we Do It!!</h3>
							</div>
							<div class="about-content">
								<p>I have always wanted to have a neighbor just like you. I've always wanted to live in a neighborhood with you. Makin their way the only way they know how. That's just a little bit more than the law will allow. On the most sensational inspirational celebrational Muppetationa. This is what we call the Muppet Show.</p>
							</div>
							<div class="row feature-content">
								<div class="col-md-4 col-sm-6 col-xs-4">
									<div class="feature-box">
										<i class="icon icon-ChartDown"></i>
									<h4>Backtrackable Alogrithm</h4>
									<p>We're gonna do it. On your mark get set and go now a dream and we just....</p>
									</div>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-4">
									<div class="feature-box">
										<i class="icon icon-ChartUp"></i>
									<h4>LARGER DATASETS</h4>
									<p>We're gonna do it. On your mark get set and go now a dream and we just....</p>
									</div>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-4">
									<div class="feature-box">
										<i class="icon_search-2"></i>
									<h4>ENHANCED PREDICTION METHOD</h4>
									<p>We're gonna do it. On your mark get set and go now a dream and we just....</p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-5 col-sm-6 col-xs-12">
							<div class="img-block"><img src="assets/images/about-img.jpg" alt="About" /></div>
						</div>
					</div><!-- Row /- -->
				</div><!-- Container /- -->
			</div><!-- About Section -->
			<div class="clearfix"></div>
			<!-- Team Section -->
			<div class="container-fluid no-left-padding no-right-padding team-section abtp-mp-change">
				<!-- Container -->
				<div class="container">
					<!-- Section Header -->
					<div class="section-header text-center">
						<h6>Our Great Team Members</h6>
						<h3>OUR MEMBERS</h3>
					</div><!-- Section Header /- -->
					<!-- Row -->
					<div class="row">
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="team-box">
								<img src="assets/images/team1.jpg" alt="Team" />
								<div class="team-detail">
									<div class="col-md-6 col-sm-6 col-xs-6">
										<h4>John Doe <span>CEO Analysist</span></h4>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<ul>
											<li><a href="#" title="Pinterest"><i class="fa fa-pinterest-p"></i></a></li>
											<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="team-box">
								<img src="assets/images/team2.jpg" alt="Team" />
								<div class="team-detail">
									<div class="col-md-6 col-sm-6 col-xs-6">
										<h4>John Doe <span>CEO Analysist</span></h4>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<ul>
											<li><a href="#" title="Pinterest"><i class="fa fa-pinterest-p"></i></a></li>
											<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="team-box">
								<img src="assets/images/team3.jpg" alt="Team" />
								<div class="team-detail">
									<div class="col-md-6 col-sm-6 col-xs-6">
										<h4>John Doe <span>CEO Analysist</span></h4>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<ul>
											<li><a href="#" title="Pinterest"><i class="fa fa-pinterest-p"></i></a></li>
											<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="team-box">
								<img src="assets/images/team4.jpg" alt="Team" />
								<div class="team-detail">
									<div class="col-md-6 col-sm-6 col-xs-6">
										<h4>John Doe <span>CEO Analysist</span></h4>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<ul>
											<li><a href="#" title="Pinterest"><i class="fa fa-pinterest-p"></i></a></li>
											<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div><!-- Row /- -->
				</div><!-- Container /- -->
			</div><!-- Team Section /- -->
			<div class="clearfix"></div>
			<div class="clearfix"></div>
			<!-- Testimonial Section -->
			<div class="container-fluid no-left-padding no-right-padding testimonial-section testimonial-section2 abtp-mp-change">
				<!-- Container -->
				<div class="container">
					<div class="col-md-offset-2 col-md-9">
						<div id="testimonial-carousel" class="carousel slide" data-ride="carousel">
							<!-- Wrapper for slides -->
							<div class="carousel-inner" role="listbox">
								<div class="item active">
									<i><img src="assets/images/testi2.jpg" alt="Testimonial"></i>
									<h3>Richard Peterson <span>Graphic Designer</span></h3>
									<p>It's time to play the music. It's time to light the lights. It's time to meet the Muppets on the Muppet Show tonight. So get a witch's shawl on a broomstick you can crawl on.</p>
								</div>
								<div class="item">
									<i><img src="assets/images/testi2.jpg" alt="Testimonial"></i>
									<h3>Richard Peterson <span>Graphic Designer</span></h3>
									<p>It's time to play the music. It's time to light the lights. It's time to meet the Muppets on the Muppet Show tonight. So get a witch's shawl on a broomstick you can crawl on.</p>
								</div>
								<div class="item">
									<i><img src="assets/images/testi2.jpg" alt="Testimonial"></i>
									<h3>Richard Peterson <span>Graphic Designer</span></h3>
									<p>It's time to play the music. It's time to light the lights. It's time to meet the Muppets on the Muppet Show tonight. So get a witch's shawl on a broomstick you can crawl on.</p>
								</div>
							</div>
							
							<!-- Indicators -->
							<ol class="carousel-indicators">
								<li data-target="#testimonial-carousel" data-slide-to="0" class="active"></li>
								<li data-target="#testimonial-carousel" data-slide-to="1"></li>
								<li data-target="#testimonial-carousel" data-slide-to="2"></li>
							</ol>
						</div>
					</div>
				</div><!-- Container /- -->
			</div><!-- Testimonial Section /- -->
			<div class="clearfix"></div>
			<!-- Query Section -->
			<div class="container-fluid no-left-padding no-right-padding query-section">
				<!-- Container -->
				<div class="container">
					<div class="col-md-6 col-sm-6 text-center">
						<h4>have a question?</h4>
					</div>
					<div class="col-md-6 col-sm-6 text-center">
						<h4><a href="contactus.html" title="CONTACT US NOW">CONTACT US NOW</a></h4>
					</div>
				</div><!-- Container /- -->
			</div><!-- Query Section /- -->
		</main>

		<!-- Footer Main -->
		
		<footer id="footer-main" class="footer-main footer-main-2 container-fluid no-left-padding no-right-padding">
			<!-- Container -->
			<div class="container">
				<!-- Row -->
				<div class="row">
					<!-- Widget About -->
					<div class="col-md-3 col-sm-6 col-xs-6">
						<aside class="widget widget_about">
							<img src="assets/images/ftr-logo.png" alt="Logo" />
							<p>Just two good ol' boys Wouldn't change if they could. Fightin' the system like a true modern day Robin Hood. Space. The final frontier. These are the voyages of the Starship Enterprise.</p>
						</aside>
						<div class="social-copy-widget">
							<ul class="footer-social">
								<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#" title="Twiiter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
							</ul>
						</div>
					</div><!-- Widget About /- -->
					<!-- Widget Links -->
					<div class="col-md-3 col-sm-6 col-xs-6">
						<aside class="widget widget_links">
							<h3 class="widget-title">Quick Links</h3>
							<ul>
								<li><a href="#" title="Services">Search</a></li>
								<li><a href="#" title="Services">Services</a></li>
								<li><a href="#" title="About Us">About Us</a></li>
							</ul>
						</aside>
					</div><!-- Widget Links /- -->
					<!-- Widget Everywhere -->
					<div class="col-md-3 col-sm-6 col-xs-6">
						<aside class="widget widget_everywhere">
							<h3 class="widget-title">We are Everywhere</h3>
							<div class="cnt-detail">
								<p><i class="icon icon-Phone2"></i><a>(+01) 123 456 7890</a></p>
								<p><i class="icon icon-Mail"></i><a href="mailto:info@svp.com">info@svp.in</a></p>
								<p><i class="icon icon-Pointer"></i>LJIET, Ahmedabad, Gujarat</p>
							</div>
						</aside>
					</div><!-- Widget Everywhere /- -->
					<!-- Widget Newsletter -->
					<div class="col-md-3 col-sm-6 col-xs-6">
						<aside class="widget widget_newsletter">
							<h3 class="widget-title">Our NewsLetter</h3>
							<form>
								<input type="text" required="" placeholder="Enter Your Email..." class="form-control">
								<input type="submit" title="SUBSCRIBE" value="SUBSCRIBE">	
							</form>
						</aside>
					</div><!-- Widget Newsletter /- -->
				</div><!-- Row /- -->
				
				<!-- Bottom Footer -->
				<div class="container-fluid no-left-padding no-right-padding btm-ftr">
					<div class="row">
						<div class="col-md-8 col-sm-12 col-xs-12">
							<!-- Ownavigation -->
							<nav class="navbar ownavigation">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-ftr" aria-expanded="false" aria-controls="navbar">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>									
								</div>
								<div id="navbar-ftr" class="navbar-collapse collapse">
									<ul class="nav navbar-nav">
										<li><a href="#" title="Home">Home</a></li>
										<li><a href="#" title="About Us">About Us</a></li>
										<li><a href="#" title="Services">Services</a></li>
										<li><a href="#" title="Contact">Contact</a></li>
									</ul>
								</div>
							</nav><!-- Ownavigation /- -->
						</div>
						
						<div class="col-md-4 col-sm-12 col-xs-12 copyright">
							<p>Copy Rights <i class="fa fa-copyright"></i> 2017 SVP All Rights Reserved</p>
						</div>
					</div>
				</div>
			</div>
		</footer>

	</div>
	
	<!-- JQuery v1.12.4 -->
	<script src="assets/js/jquery-1.12.4.min.js"></script>

	<!-- Library - Js -->
	<script src="assets/js/lib.js"></script>
	
	<!-- Library - Theme JS -->
	<script src="assets/js/functions.js"></script>
	
</body>
</html>