<!DOCTYPE html>
<!--[if lt IE 7 ]> <html class="ie6"> <![endif]-->
<!--[if IE 7 ]>    <html class="ie7"> <![endif]-->
<!--[if IE 8 ]>    <html class="ie8"> <![endif]-->
<!--[if IE 9 ]>    <html class="ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en"><!--<![endif]-->
<head>
	<meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">
    <meta name="author" content="">

	<title>Home - SVP</title>
	<link rel="icon" type="image/x-icon" href="assets/images//favicon.ico" />
	<link rel="apple-touch-icon-precomposed" href="assets/images//apple-touch-icon-114x114-precomposed.png">
	<link rel="apple-touch-icon-precomposed" href="assets/images//apple-touch-icon-72x72-precomposed.png">
	<link rel="apple-touch-icon-precomposed" href="assets/images//apple-touch-icon-57x57-precomposed.png">	
	<link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i|Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/revolution/css/settings.css">
	<link rel="stylesheet" type="text/css" href="assets/revolution/fonts/font-awesome/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="assets/revolution/fonts/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/revolution/css/layers.css">
	<link rel="stylesheet" type="text/css" href="assets/revolution/css/navigation.css">
    <link href="assets/css/lib.css" rel="stylesheet">
	<link href="assets/css/plugins.css" rel="stylesheet">
	<link href="assets/css/elements.css" rel="stylesheet">	
	<link href="assets/css/rtl.css" rel="stylesheet">	
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body data-offset="200" data-spy="scroll" data-target=".ownavigation">
	<div class="main-container">
				<header class="header_s header_s2">
			<div id="slidepanel">
				<div class="container-fluid no-left-padding no-right-padding top-header">
					<div class="container">
						<div class="row">
							<div class="col-md-6 col-sm-6 col-xs-12 welcome-line">
								<h6>Welcome to Stock Value Predictor</h6>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-12 block-cnt">
								<ul class="top-social">
									<li><a href="#" title="Twitter"><i class="fa fa-pinterest-p"></i></a></li>
									<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
									<li><a href="#" title="linkedin"><i class="fa fa-linkedin"></i></a></li>
								</ul>
								<a href="#">Search</a>
							</div>
						</div>
					</div><!-- Container /- -->
				</div><!-- Top Header /- -->
				<!-- Middle Header -->
				<div class="container-fluid no-left-padding no-right-padding middle-header">
					<!-- Container -->
					<div class="container">
						<div class="row">
							<div class="col-md-offset-2 col-md-10">
								<span><i class="icon icon-Phone2"></i><a>(+01) 123 456 7890</a></span>
								<span><i class="icon icon-Mail"></i><a href="mailto:info@svp.in">info@svp.in</a></span>
								<div class="search-block">
									<div class="input-group">
										<input type="text" class="form-control" placeholder="Search for...">
										<span class="input-group-btn">
											<button class="btn btn-default" type="button"><i class="icon icon-Search"></i></button>
										</span>
									</div><!-- /input-group -->
								</div>
							</div>
						</div>
					</div><!-- Container /- -->
				</div><!-- Middle Header /- -->
			</div><!-- SidePanel /- -->
			
			<!-- Ownavigation -->
			<nav class="navbar ownavigation">
				<!-- Container -->
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="index.php"><img src="" alt="logo"></a>
					</div>
					<div class="menu-switch">	
						<a href="javascript:void(0);" title="menu"><i class="fa fa-bars"></i></a>
					</div>
					<div id="navbar" class="navbar-collapse collapse navbar-right">
						<ul class="nav navbar-nav">
							<li class="dropdown active">
								<a href="index.php" class="dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false">Home</a>
								<i class="ddl-switch fa fa-angle-down"></i>
							</li>
							<li><a href="about.php" title="About Us">About Us</a></li>
							<li><a href="about.php" title="About Us">Info</a></li>
							<li><a href="about.php" title="About Us">ANALYSIS</a></li>
							<li><a href="about.php" title="About Us">HISTORISIS</a></li>

							<li><a href="#" title="Services">Services</a></li>
							<li><a href="contactus.html" title="Contact">Contact</a></li>
						</ul>
					</div>
				</div><!-- Container /- -->
			</nav><!-- Ownavigation /- -->
		</header>

		<main class="site-main">
			
			<!-- Slider Section 2 -->
			<div id="home-revslider" class="slider-section slider-section2 container-fluid no-padding">
				<!-- START REVOLUTION SLIDER 5.0 -->
				<div class="rev_slider_wrapper">
					<div id="home-slider2" class="rev_slider" data-version="5.0">
						<ul>
							<li>
								<img src="assets/images/banner2.jpg" alt="slider" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
								<div class="tp-caption NotGeneric-Title tp-resizeme rs-parallaxlevel-0" id="slide-layer-1" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['155','100','60','40']" 
									data-fontsize="['44','40','32','23']"
									data-lineheight="['72','62','52','42']"
									data-width="['900','900','900','400']"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
									data-transform_in="x:[-105%];s:1000;e:Power4.slideInRight;" 
									data-transform_out="y:[100%];s:1000;s:1000;e:Power2.slideInRight;" 
									data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
									data-start="1000" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on"
									data-elementdelay="0.05" 
									style="z-index: 5; white-space: nowrap; letter-spacing: 1.1px; color:#fff; font-weight: bold;  font-family: 'Raleway', sans-serif;">Search Stock Prices <span style="color: #ffb300"><br>See, their</span> <span style="color: #ffb300">Prediction, Analysis  </span> & More!
								</div>
								<div class="tp-caption NotGeneric-Title tp-resizeme rs-parallaxlevel-0" id="slide-layer-2" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['320','240','180','135']" 
									data-width="none"
									data-height="none"
									data-transform_idle="o:1;"
									data-transform_in="x:[0];s:1000;e:Power4.zoomIn;" 
									data-transform_out="y:[0];s:1000;s:1000;e:Power2.zoomIn;" 
									data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
									data-start="1000" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on"
									data-elementdelay="0.05" 
									style="z-index: 5; white-space: nowrap;"><img src="assets/images/slider-seprator.png" alt="Sep" />
								</div>
								<div class="tp-caption NotGeneric-Title tp-resizeme rs-parallaxlevel-0" id="slide-layer-4" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['360','270','210','160']" 
									data-fontsize="['14','14','14','14']"
									data-lineheight="['24','24','24','24']"
									data-width="['750','750','750','400']"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
									data-transform_in="y:-50px;opacity:0;s:1000;e:Power4.easeOut;" 
									data-transform_out="opacity:0;s:1000;e:Power4.easeIn;s:1000;e:Power4.easeIn;"
									data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
									data-start="1000" 
									data-splitin="chars" 
									data-splitout="none" 
									data-responsive_offset="on"
									data-elementdelay="0.05" 
									style="z-index: 5; white-space: nowrap; letter-spacing: 0.49px; color:#fff; font-family: 'Open Sans', sans-serif; font-weight: normal;"><!-- Come and listen to a story about a man named Jed - a poor mountaineer barely kept his <br>family fed! And we know Flipper lives in a world full. -->
								</div>
								<div class="tp-caption NotGeneric-Button rev-btn  rs-parallaxlevel-0" id="slide-layer-5" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['450','350','295','240']" 
									data-fontsize="['15','15','15','15']"
									data-lineheight="['30','30','30','30']"
									data-width="none"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
									data-transform_in="x:[105%];s:1000;e:Power4.slideInLeft;" 
									data-transform_out="y:[100%];s:1000;s:1000;e:Power2.slideInLeft;"
									data-style_hover="c:#fff;bg:#ffb300;"
									data-start="3000" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on" 
									data-responsive="off"
									style="z-index: 10;padding:9px 35px 8px;border-radius: 0;border: none;border-left: 3px solid #ffb300; letter-spacing:0.75px; color: #fff; background-color: #0056b7; font-weight: 600; font-family: 'Open Sans', sans-serif; text-transform:uppercase; white-space: nowrap;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">SEE PREDICTION
								</div>
							</li>
							
							<li>
								<img src="assets/images/banner6.jpg" alt="slider" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
								<div class="tp-caption NotGeneric-Title tp-resizeme rs-parallaxlevel-0" id="slide-1-layer-1" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['155','100','60','40']" 
									data-fontsize="['44','40','32','23']"
									data-lineheight="['72','62','52','42']"
									data-width="['900','900','900','400']"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
									data-transform_in="x:[-105%];s:1000;e:Power4.slideInRight;" 
									data-transform_out="y:[100%];s:1000;s:1000;e:Power2.slideInRight;" 
									data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
									data-start="1000" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on"
									data-elementdelay="0.05" 
									style="z-index: 5; white-space: nowrap; letter-spacing: 1.1px; color:#fff; font-weight: bold;  font-family: 'Raleway', sans-serif;">Search Stock Prices <span style="color: #ffb300"><br>See, their</span> <span style="color: #ffb300">Prediction, Analysis  </span> & More!
								</div>
								<div class="tp-caption NotGeneric-Title tp-resizeme rs-parallaxlevel-0" id="slide-1-layer-2" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['320','240','180','135']" 
									data-width="none"
									data-height="none"
									data-transform_idle="o:1;"
									data-transform_in="x:[0];s:1000;e:Power4.zoomIn;" 
									data-transform_out="y:[0];s:1000;s:1000;e:Power2.zoomIn;" 
									data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
									data-start="1000" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on"
									data-elementdelay="0.05" 
									style="z-index: 5; white-space: nowrap;"><img src="assets/images/slider-seprator.png" alt="Sep" />
								</div>
								<div class="tp-caption NotGeneric-Title tp-resizeme rs-parallaxlevel-0" id="slide-1-layer-4" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['360','270','210','160']" 
									data-fontsize="['14','14','14','14']"
									data-lineheight="['24','24','24','24']"
									data-width="['750','750','750','400']"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
									data-transform_in="y:-50px;opacity:0;s:1000;e:Power4.easeOut;" 
									data-transform_out="opacity:0;s:1000;e:Power4.easeIn;s:1000;e:Power4.easeIn;"
									data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
									data-start="1000" 
									data-splitin="chars" 
									data-splitout="none" 
									data-responsive_offset="on"
									data-elementdelay="0.05" 
									style="z-index: 5; white-space: nowrap; letter-spacing: 0.49px; color:#fff; font-family: 'Open Sans', sans-serif; font-weight: normal;"><!-- Come and listen to a story about a man named Jed - a poor mountaineer barely kept his <br>family fed! And we know Flipper lives in a world full. -->
								</div>
							</li>
							<li>
								<img src="assets/images/banner11.jpg" alt="slider" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
								<div class="tp-caption NotGeneric-Title tp-resizeme rs-parallaxlevel-0" id="slide-2-layer-1" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['155','100','60','40']" 
									data-fontsize="['44','40','32','23']"
									data-lineheight="['72','62','52','42']"
									data-width="['900','900','900','400']"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
									data-transform_in="x:[-105%];s:1000;e:Power4.slideInRight;" 
									data-transform_out="y:[100%];s:1000;s:1000;e:Power2.slideInRight;" 
									data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
									data-start="1000" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on"
									data-elementdelay="0.05" 
									style="z-index: 5; white-space: nowrap; letter-spacing: 1.1px; color:#fff; font-weight: bold;  font-family: 'Raleway', sans-serif;">Search Stock Prices <span style="color: #ffb300"><br>See, their</span> <span style="color: #ffb300">Prediction, Analysis  </span> & More!
								</div>
								<div class="tp-caption NotGeneric-Title tp-resizeme rs-parallaxlevel-0" id="slide-2-layer-2" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['320','240','180','135']" 
									data-width="none"
									data-height="none"
									data-transform_idle="o:1;"
									data-transform_in="x:[0];s:1000;e:Power4.zoomIn;" 
									data-transform_out="y:[0];s:1000;s:1000;e:Power2.zoomIn;" 
									data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
									data-start="1000" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on"
									data-elementdelay="0.05" 
									style="z-index: 5; white-space: nowrap;"><img src="assets/images/slider-seprator.png" alt="Sep" />
								</div>
								<div class="tp-caption NotGeneric-Title tp-resizeme rs-parallaxlevel-0" id="slide-2-layer-4" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['360','270','210','160']" 
									data-fontsize="['14','14','14','14']"
									data-lineheight="['24','24','24','24']"
									data-width="['750','750','750','400']"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
									data-transform_in="y:-50px;opacity:0;s:1000;e:Power4.easeOut;" 
									data-transform_out="opacity:0;s:1000;e:Power4.easeIn;s:1000;e:Power4.easeIn;"
									data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;"  
									data-start="1000" 
									data-splitin="chars" 
									data-splitout="none" 
									data-responsive_offset="on"
									data-elementdelay="0.05" 
									style="z-index: 5; white-space: nowrap; letter-spacing: 0.49px; color:#fff; font-family: 'Open Sans', sans-serif; font-weight: normal;"><!-- Come and listen to a story about a man named Jed - a poor mountaineer barely kept his <br>family fed! And we know Flipper lives in a world full. -->
								</div>
								<div class="tp-caption NotGeneric-Button rev-btn  rs-parallaxlevel-0" id="slide-2-layer-5" 
									data-x="['left','left','left','left']" data-hoffset="['380','140','70','30']" 
									data-y="['top','top','top','top']" data-voffset="['450','350','295','240']" 
									data-fontsize="['15','15','15','15']"
									data-lineheight="['30','30','30','30']"
									data-width="none"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
									data-transform_in="x:[105%];s:1000;e:Power4.slideInLeft;" 
									data-transform_out="y:[100%];s:1000;s:1000;e:Power2.slideInLeft;"
									data-style_hover="c:#fff;bg:#ffb300;"
									data-start="3000" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on" 
									data-responsive="off"
									style="z-index: 10;padding:9px 35px 8px;border-radius: 0;border: none;border-left: 3px solid #ffb300; letter-spacing:0.75px; color: #fff; background-color: #0056b7; font-weight: 600; font-family: 'Open Sans', sans-serif; text-transform:uppercase; white-space: nowrap;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">SEE PREDICTION
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div><!-- Slider Section 2 -->
			
			<!-- Process Section -->
			<div class="container-fluid no-left-padding no-right-padding process-section">
				<!-- Container -->
				<div class="container">
					<div class="col-md-3 col-sm-4 col-xs-4 process-box">
						<i class="icon icon-Search"></i>
						<h5><span>SEARCHING</span> HISTORICAL DATA</h5>
					</div>
					<div class="col-md-3 col-sm-4 col-xs-4 process-box">
						<i class="icon icon-ChemicalGlass"></i>
						<h5><span>PROCESS</span> DATA</h5>
					</div>
					<div class="col-md-3 col-sm-4 col-xs-4 process-box">
						<i class="icon icon-Anchor"></i>
						<h5><span>ANALYZE</span> SENTIMENT</h5>
					</div>
					<div class="col-md-3 col-sm-4 col-xs-4 process-box">
						<i class="icon icon-ChartUp"></i>
						<h5><span>PREDICT</span> STOCK VALUE</h5>
					</div>
				</div><!-- Container /- -->
			</div><!-- Process Section /- -->
			<div class="clearfix"></div>
			<!-- About Section -->
			<div class="container-fluid no-left-padding no-right-padding about-section">
				<!-- Container -->
				<div class="container">
					<!-- Row -->
					<div class="row">
						<div class="col-md-7 col-sm-6 col-xs-6">
							<!-- Section Header -->
							<div class="section-header text-left">
								<h6>About SVP</h6>
								<h3>How we do It!!</h3>
							</div><!-- Section Header /- -->
							<div class="about-content">
								<p>I have always wanted to have a neighbor just like you. I've always wanted to live in a neighborhood with you. Makin their way the only way they know how. That's just a little bit more than the law will allow. On the most sensational inspirational celebrational Muppetationa. This is what we call the Muppet Show.</p>
							</div>
						</div>
						<div class="col-md-5 col-sm-6 col-xs-6 abt-img">
							<div class="img-block"><img src="assets/images/about-img.jpg" alt="About" /></div>
						</div>
						<div class="feature-content col-md-7 no-left-padding no-right-padding">
							<div class="col-md-4 col-sm-4 col-xs-4">
								<div class="feature-box">
									<i class="icon icon-Users"></i>
									<h4>Backtrackable Alogrithm</h4>
									<p>We're gonna do it. On your mark get set and go now a dream and we just....</p>
								</div>
							</div>
							<div class="col-md-4 col-sm-4 col-xs-4">
								<div class="feature-box">
									<i class="icon icon-ChartUp"></i>
									<h4>LARGER DATASETS</h4>
									<p>We're gonna do it. On your mark get set and go now a dream and we just....</p>
								</div>
							</div>
							<div class="col-md-4 col-sm-4 col-xs-4">
								<div class="feature-box">
									<i class="icon_search-2"></i>
									<h4>ENHANCED PREDICTION METHOD</h4>
									<p>We're gonna do it. On your mark get set and go now a dream and we just....</p>
								</div>
							</div>
						</div>
					</div><!-- Row /- -->
				</div><!-- Container /- -->
			</div><!-- About Section -->
			<div class="clearfix"></div>
			<!-- Skill Section -->
			<div class="container-fluid no-left-padding no-right-padding skill-section">
				<!-- Container -->
				<div class="container">
					<!-- Section Header -->
					<div class="section-header text-center">
						<h6>We predict Values	 on the following</h6>
						<h3>Testing Parameters</h3>
					</div><!-- Section Header /- -->
					<!-- Row -->
					<div class="row">
						<div class="col-md-7 col-sm-6 col-xs-12">
							<div id="skill_type-1" class="skill-block">
								<div class="skill-progress-box">
									<h3 class="block-title">Historical Data</h3>
									<div class="progress-box">
										<span data-skill_percent="77" id="skill_1_count-1"></span>
										<div class="progress">
											<div class="progress-bar progress-bar-danger" role="progressbar" id="skill_bar_1_count-1"></div>
										</div>
									</div>
								</div>
								<div class="skill-progress-box">
									<h3 class="block-title">Sentimental Analyses</h3>
									<div class="progress-box">
										<span data-skill_percent="90" id="skill_1_count-2"></span>
										<div class="progress">
											<div class="progress-bar progress-bar-danger" role="progressbar" id="skill_bar_1_count-2"></div>
										</div>
									</div>
								</div>
								<div class="skill-progress-box">
									<h3 class="block-title">Regression based Calculations</h3>
									<div class="progress-box">
										<span data-skill_percent="80" id="skill_1_count-3"></span>
										<div class="progress">
											<div class="progress-bar progress-bar-danger" role="progressbar" id="skill_bar_1_count-3"></div>
										</div>
									</div>
								</div>
								<div class="skill-progress-box">
									<h3 class="block-title">P/E ratio</h3>
									<div class="progress-box">
										<span data-skill_percent="87" id="skill_1_count-4"></span>
										<div class="progress">
											<div class="progress-bar progress-bar-danger" role="progressbar" id="skill_bar_1_count-4"></div>
										</div>
									</div>
								</div>
								<div class="skill-progress-box">
									<h3 class="block-title">SOCIAL MEDIA Portfolio</h3>
									<div class="progress-box">
										<span data-skill_percent="95" id="skill_1_count-5"></span>
										<div class="progress">
											<div class="progress-bar progress-bar-danger" role="progressbar" id="skill_bar_1_count-5"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-5 col-sm-6 col-xs-12 video-block">
							<div class="video-box">
								<img src="assets/images/video-block.jpg" alt="Video" />
								<a class="popup-youtube" href="http://www.youtube.com/watch?v=0O2aH4XLbto"><i class="icon icon-Play"></i></a>
							</div>
						</div>
					</div><!-- Row /- -->
				</div><!-- Container /- -->
			</div><!-- Skill Section /- -->
			<!-- Team Section -->
			<div class="container-fluid no-left-padding no-right-padding team-section">
				<div class="container">
					<div class="section-header text-center">
						<h6>Our Great Team Members</h6>
						<h3>OUR MEMBERS</h3>
					</div>
					<div class="row">
						<div class="col-md-3 col-sm-6 col-xs-6">
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="team-box">
								<img src="assets/images/team2.jpg" alt="Team" />
								<div class="team-detail">
									<div class="col-md-6 col-sm-6 col-xs-6">
										<h4>John Doe <span>CEO Analysist</span></h4>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<ul>
											<li><a href="#" title="Pinterest"><i class="fa fa-pinterest-p"></i></a></li>
											<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="team-box">
								<img src="assets/images/team3.jpg" alt="Team" />
								<div class="team-detail">
									<div class="col-md-6 col-sm-6 col-xs-6">
										<h4>John Doe <span>CEO Analysist</span></h4>
									</div>
									<div class="col-md-6 col-sm-6 col-xs-6">
										<ul>
											<li><a href="#" title="Pinterest"><i class="fa fa-pinterest-p"></i></a></li>
											<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
						</div>
					</div><!-- Row /- -->
				</div><!-- Container /- -->
			</div><!-- Team Section /- -->
			<div class="clearfix"></div>
			<!-- Testimonial Section -->
			<div class="container-fluid no-left-padding no-right-padding testimonial-section testimonial-section2">
				<!-- Container -->
				<div class="container">
					<div class="col-md-offset-2 col-md-9">
						<div id="testimonial-carousel" class="carousel slide" data-ride="carousel">
							<!-- Wrapper for slides -->
							<div class="carousel-inner" role="listbox">
								<div class="item active">
									<i><img src="assets/images/team3.jpg" alt="Testimonial"></i>
									<h3>Richard Peterson <span>Graphic Designer</span></h3>
									<p>It's time to play the music. It's time to light the lights. It's time to meet the Muppets on the Muppet Show tonight. So get a witch's shawl on a broomstick you can crawl on.</p>
								</div>
								<div class="item">
									<i><img src="assets/images/testi2.jpg" alt="Testimonial"></i>
									<h3>Richard Peterson <span>Graphic Designer</span></h3>
									<p>It's time to play the music. It's time to light the lights. It's time to meet the Muppets on the Muppet Show tonight. So get a witch's shawl on a broomstick you can crawl on.</p>
								</div>
								<div class="item">
									<i><img src="assets/images/testi2.jpg" alt="Testimonial"></i>
									<h3>Richard Peterson <span>Graphic Designer</span></h3>
									<p>It's time to play the music. It's time to light the lights. It's time to meet the Muppets on the Muppet Show tonight. So get a witch's shawl on a broomstick you can crawl on.</p>
								</div>
							</div>
							
							<!-- Indicators -->
							<ol class="carousel-indicators">
								<li data-target="#testimonial-carousel" data-slide-to="0" class="active"></li>
								<li data-target="#testimonial-carousel" data-slide-to="1"></li>
								<li data-target="#testimonial-carousel" data-slide-to="2"></li>
							</ol>
						</div>
					</div>
				</div><!-- Container /- -->
			</div><!-- Testimonial Section /- -->
			<div class="clearfix"></div>	
			<!-- Query Section -->
			<div class="container-fluid no-left-padding no-right-padding query-section">
				<!-- Container -->
				<div class="container">
					<div class="col-md-6 col-sm-6 text-center">
						<h4>have a question?</h4>
					</div>
					<div class="col-md-6 col-sm-6 text-center">
						<h4><a href="contactus.html" title="CONTACT US NOW">CONTACT US NOW</a></h4>
					</div>
				</div><!-- Container /- -->
			</div><!-- Query Section /- -->
		</main>
		
		<!-- Footer Main -->
		<footer id="footer-main" class="footer-main footer-main-2 container-fluid no-left-padding no-right-padding">
			<!-- Container -->
			<div class="container">
				<!-- Row -->
				<div class="row">
					<!-- Widget About -->
					<div class="col-md-3 col-sm-6 col-xs-6">
						<aside class="widget widget_about">
							<img src="assets/images/ftr-logo.png" alt="Logo" />
							<p>Just two good ol' boys Wouldn't change if they could. Fightin' the system like a true modern day Robin Hood. Space. The final frontier. These are the voyages of the Starship Enterprise.</p>
						</aside>
						<div class="social-copy-widget">
							<ul class="footer-social">
								<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#" title="Twiiter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
							</ul>
						</div>
					</div><!-- Widget About /- -->
					<!-- Widget Links -->
					<div class="col-md-3 col-sm-6 col-xs-6">
						<aside class="widget widget_links">
							<h3 class="widget-title">Quick Links</h3>
							<ul>
								<li><a href="#" title="Services">Search</a></li>
								<li><a href="#" title="Services">Services</a></li>
								<li><a href="#" title="About Us">About Us</a></li>
							</ul>
						</aside>
					</div><!-- Widget Links /- -->
					<!-- Widget Everywhere -->
					<div class="col-md-3 col-sm-6 col-xs-6">
						<aside class="widget widget_everywhere">
							<h3 class="widget-title">We are Everywhere</h3>
							<div class="cnt-detail">
								<p><i class="icon icon-Phone2"></i><a>(+01) 123 456 7890</a></p>
								<p><i class="icon icon-Mail"></i><a href="mailto:info@svp.com">info@svp.in</a></p>
								<p><i class="icon icon-Pointer"></i>LJIET, Ahmedabad, Gujarat</p>
							</div>
						</aside>
					</div><!-- Widget Everywhere /- -->
					<!-- Widget Newsletter -->
					<div class="col-md-3 col-sm-6 col-xs-6">
						<aside class="widget widget_newsletter">
							<h3 class="widget-title">Our NewsLetter</h3>
							<form>
								<input type="text" required="" placeholder="Enter Your Email..." class="form-control">
								<input type="submit" title="SUBSCRIBE" value="SUBSCRIBE">	
							</form>
						</aside>
					</div><!-- Widget Newsletter /- -->
				</div><!-- Row /- -->
				
				<!-- Bottom Footer -->
				<div class="container-fluid no-left-padding no-right-padding btm-ftr">
					<div class="row">
						<div class="col-md-8 col-sm-12 col-xs-12">
							<!-- Ownavigation -->
							<nav class="navbar ownavigation">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-ftr" aria-expanded="false" aria-controls="navbar">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>									
								</div>
								<div id="navbar-ftr" class="navbar-collapse collapse">
									<ul class="nav navbar-nav">
										<li><a href="#" title="Home">Home</a></li>
										<li><a href="#" title="About Us">About Us</a></li>
										<li><a href="#" title="Services">Services</a></li>
										<li><a href="#" title="Contact">Contact</a></li>
									</ul>
								</div>
							</nav><!-- Ownavigation /- -->
						</div>
						
						<div class="col-md-4 col-sm-12 col-xs-12 copyright">
							<p>Copy Rights <i class="fa fa-copyright"></i> 2017 SVP All Rights Reserved</p>
						</div>
					</div>
				</div>
			</div>
		</footer>

	</div>
	<script src="assets/js/jquery-1.12.4.min.js"></script>
	<script src="assets/js/lib.js"></script>
	<script type="text/javascript" src="assets/revolution/js/jquery.themepunch.tools.min.js?rev=5.0"></script>
	<script type="text/javascript" src="assets/revolution/js/jquery.themepunch.revolution.min.js?rev=5.0"></script>
	<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.video.min.js"></script>
	<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
	<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
	<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDW40y4kdsjsz714OVTvrw7woVCpD8EbLE"></script>
	<script src="assets/js/functions.js"></script>
</body>
</html>