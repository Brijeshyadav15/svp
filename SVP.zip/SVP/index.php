  <!doctype html>
<html lang="en" class="no-js">
<head>
  <meta charset="UTF-8" />
  <title>Index -SVP</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css"/>
  <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
  <script type='text/javascript' src='jquery.particleground.js'></script>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <script
        src="https://code.jquery.com/jquery-3.2.1.js"
        integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
        crossorigin="anonymous"></script>
  <script type='text/javascript' src='js/demo.js'></script>
  <script src="d3.js" charset="utf-8"></script>
    <style type="text/css">
      .chart-gauge
      {
        width: 400px;
        margin: 100px auto  
        margin-bottom:0%;
        margin-top:0px;
        margin-left:35%; 
        margin-right:35%; 
       } 
      .chart-filled
      {
        fill: steelblue;
      }
      .chart-empty
      {
        fill: #dedede;
      }
      .needle, .needle-center
      {
        fill: white;
      }
      svg 
      {
        font: 10px sans-serif;
      }
    </style>
</head>
<body>
      <div id="particles">
            <div id="intro">
                    <h1>Stock Value Predictor</h1>
                          <form method="post" action="home.php">
                              <input type="search" name="search" id="search" class="fa fa-search" list="stocklist">
                                  <!-- <a id="FILTERS">FILTERS</a> -->
                                  <datalist id='stocklist'>
                                      <?php
                                      /*$conn=new mysqli("localhost","root","","svp");

                                      $results = mysqli_query($conn,"SELECT DISTINCT * FROM ticker");
                                      while ($row=mysqli_fetch_array($results)) 
                                      {
                                          echo "<option label='".$row['Company_Name']."' value='".$row['Symbol']."'></option>";
                                      }*/ 
                                      ?>
                                  </datalist> 
                                  &nbsp;
                                  
                              <br><br>
                              <span class="btn btn-primary" id="search-btn">Search Predictions</span>
                              &nbsp;&nbsp;&nbsp;&nbsp;
                          
                              <button id="SKIP" class="btn" id="skip-btn">SKIP TO MAIN SITE</button> 
                    <div class="chart-gauge" id="chart"></div>  
            </div>  
      </div>
</body>
</html>

<script type="text/javascript" src="d3_gauge.js"></script>
<script type="text/javascript">
$( document ).ready(function() {
    // $( "#chart").hide();
    // $( "#COUNTRY").hide();
    // $( "#EXCHANGE").hide();
    $( "#search-btn" ).click(function() 
    {
      $( "#chart").show();
    })
    $( "#skip-btn" ).click(function() 
    {
         window.location.href="home.php";
    })
    $( "#FILTERS" ).click(function() 
    {
      $("#COUNTRY").toggle();
      $("#EXCHANGE").toggle();
    })
});
</script>